/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university_db;

import java.awt.AWTEventMulticaster;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;


public class SearchData extends JFrame {

    private static String table_name;
    private static int col_no;
    private String[] val;
    private static String[] col_names;
    private String q;
    private String[] name;

    JPanel jp = new JPanel();
    JLabel[] jl;
    JCheckBox[] jc;
    JTextField[] jt;
    JButton jb = new JButton("Update");
    private List<JCheckBox> checkBoxList = new ArrayList<>();
    JButton close_bttn = new JButton("Close");

    DatabaseHandler ob1 = new DatabaseHandler();
    dbTest d  = new dbTest();

    public SearchData(String table_name, int col_no, String[] col_names, String query) {
        this.table_name = table_name;
        this.col_no = col_no;
        this.q = query;
        

        ob1.setConnection("university_database", "root", "");

        //System.out.println(table_name + " " + col_no);

        setTitle("Update data");
        setVisible(true);
        setSize(650, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        jt = new JTextField[col_no + 1];
        jl = new JLabel[col_no + 1];
        val = new String[col_no + 1];
        jc = new JCheckBox[col_no +1];

        int j = 10;

        for (int i = 0; i < col_no; i++) {
            String text = col_names[i];
            jt[i] = new JTextField();
            //jl[i] = new JLabel();
            jc[i] = new JCheckBox(text);

            //jc[i].setBounds(0, j, 100, 30);
            jc[i].setBounds(10, j, 120, 30);
            //jc[i].setEnabled(true);
            //checkBoxList.add(jc[i]);
            //jc[i].setText(col_names[i]);
            jt[i].disable();
            jt[i].setBounds(225, j, 160, 30);
            
            
            j += 50;
            
            add(jc[i]);
            add(jt[i]);
        }

        j += 60;

        jb.setBounds(60, j, 100, 40);

        close_bttn.setBounds(225, j, 100, 40);

        add(jb);

        add(close_bttn);

        add(jp);
        
        jc[0].addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                String p = null;
                jt[0].setEnabled(true);
                p += jc[0].getText().toString();
            }
        });
        
        jb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < col_no; i++) {
                    val[i] = jt[i].getText();
                    System.out.println(jt[i].getText());
                }
                //ob1.update(val,q);
            }
        });

        close_bttn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

    }

    public static void main(String[] args) {
        insertForm t = new insertForm(table_name, col_no, col_names);
    }
}
