/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university_db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author Rafee
 */
public class DatabaseHandler {

    Connection connect = null;
    Statement statement = null;
    PreparedStatement pStatement = null;
    ResultSet result = null;
    ArrayList<String> columnName = new ArrayList<String>();
    private String databaseName;
    String q;

    private String[] tableName = new String[20];

    private int sz_insertion;
    private int updateVal;
    Vector data = new Vector();
    Vector cname = new Vector();

    public void setConnection(String a, String b, String c) {
        try {
            Class.forName("com.mysql.jdbc.Driver");

            this.databaseName = a;

            String url = "jdbc:mysql://localhost/" + databaseName;

            String user = b;

            String password = c;

            c = null;

            connect = DriverManager.getConnection(url, user, password);

            JOptionPane.showMessageDialog(null, "Connection Successfull");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Connection Unsuccessfull");
            e.printStackTrace();
        }

    }

    public String[] showtable() {
        try {
            String[] types = {"TABLE"};

            result = connect.getMetaData().getTables(this.databaseName, null, "%", types);

            int i = 0;

            while (result.next()) {
                tableName[i] = result.getString(3);
                i++;
                // System.out.println(tableName);
            }
        } catch (Exception e) {
            System.out.println("Error in Query..");
            e.printStackTrace();
        }
        return tableName;
    }

    //select all data from table
    public ResultSet testQuery(String table_name) {
        try {

            String query = "SELECT * FROM " + table_name;
            statement = connect.createStatement();
            result = statement.executeQuery(query);

            System.out.println("Query is successful");

        } catch (Exception e) {
            System.out.println("Error in query..");
            e.printStackTrace();
        }
        return result;
    }

    public ArrayList<ArrayList<String>> getResult(ResultSet result) {

        ArrayList<ArrayList<String>> records = new ArrayList<ArrayList<String>>();
        if (columnName != null) {
            columnName.clear();
        }

        try {

            ArrayList<String> colName = new ArrayList<String>();

            for (int i = 1; i <= result.getMetaData().getColumnCount(); i++) {
                colName.add(result.getMetaData().getColumnName(i));
                
            }
       
           
            //shows column names
            for (String cc : colName) {
                System.out.print(cc + " ");
                columnName.add(cc);
            }

            System.out.println("");

            while (result.next()) {
                ArrayList<String> r = new ArrayList<String>();

                for (String cc : colName) {
                    r.add(result.getString(cc));
                }

                records.add(r);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return records;
    }

    public void insertData(String table_name, String[] val) {
        try {
            String query = "INSERT INTO " + table_name + " VALUES(";

            sz_insertion = val.length - 1;
             
            for (int i = 1; i <= sz_insertion; i++) {
                query += "?";
                if (i < sz_insertion) {
                    query += ",";
                }
            }
            query += ")";

            System.out.println(query);

            /*
            String value;
            
            for(int i=0; i<3; i++)
            {
                value.concat(val[i]);
            }
            
            query.concat(value);
             */
            pStatement = connect.prepareStatement(query);

            for (int i = 0; i < sz_insertion; i++) {
                pStatement.setString(i + 1, val[i]);
            }
            System.out.println(query);

            pStatement.executeUpdate();

            JOptionPane.showMessageDialog(null, "Insertion Successfull");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        }
    }
  
    
   public void update(String[] val, String query){
       
       try {
            q = query;
            System.out.println(q);
            updateVal = val.length - 1;
            pStatement = connect.prepareStatement(q);

            for (int i = 0; i < updateVal; i++) {
                pStatement.setString(i + 1, val[i]);
            }
            System.out.println(query);

            pStatement.executeUpdate();

            JOptionPane.showMessageDialog(null, "Updated Successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
        }
       
   }

    public void deleteData(String table_name, String col_name, String val) {
        try {
            System.out.println(table_name + " " + col_name + " " + val);

            String query = "DELETE FROM " + table_name + " WHERE " + col_name + "= ?";
            System.out.println(query);

            pStatement = connect.prepareStatement(query);

            pStatement.setString(1, val);

            pStatement.executeUpdate();

            JOptionPane.showMessageDialog(null, "Deleted Successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Not deleted");
            e.printStackTrace();
        }
    }

    public void addColumn(String table_name, String col_name, String col_type) {
        try {
            String query = "ALTER TABLE " + table_name + " ADD " + col_name + " " + col_type;

            System.out.println(query);

            statement = connect.createStatement();

            int s = statement.executeUpdate(query);

            System.out.println(s);

            JOptionPane.showMessageDialog(null, "Added Column Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
